<?php

namespace Tests\Feature;

use Tests\TestCase;

class PageRoutesTest extends TestCase
{
    public function test_home_page_is_available(): void
    {
        $this->get(route('home'))->assertOk()->assertSee('PurplePOS')->assertSee('Everything you need to keep business')->assertSee('professional-chart', false);
    }

    public function test_about_page_is_available(): void
    {
        $this->get(route('about'))->assertOk()->assertSee('One request, three clear responsibilities');
    }

    public function test_customer_page_lists_static_records(): void
    {
        $this->get(route('customers.index'))->assertOk()->assertSee('Customer accounts')->assertSeeText('6 customer records')->assertSee('Amelia Santos')->assertSee('Noah Bautista');
    }

    public function test_user_page_lists_static_records(): void
    {
        $this->get(route('users.index'))->assertOk()->assertSee('User accounts')->assertSee('Karl Ramos')->assertSee('Rafael Dizon');
    }
}
