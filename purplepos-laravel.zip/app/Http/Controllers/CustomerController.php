<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class CustomerController extends Controller
{
    /** Display the customer directory using temporary static data. */
    public function index(): View
    {
        $customers = [
            ['id' => 'CUS-1001', 'name' => 'Amelia Santos', 'email' => 'amelia.santos@example.com', 'phone' => '+63 917 123 4567', 'joined' => 'Jan 12, 2026', 'orders' => 24, 'spent' => 48650.00, 'status' => 'Active', 'initials' => 'AS'],
            ['id' => 'CUS-1002', 'name' => 'Gabriel Reyes', 'email' => 'gabriel.reyes@example.com', 'phone' => '+63 918 234 5678', 'joined' => 'Feb 03, 2026', 'orders' => 18, 'spent' => 32780.50, 'status' => 'Active', 'initials' => 'GR'],
            ['id' => 'CUS-1003', 'name' => 'Sofia Mendoza', 'email' => 'sofia.mendoza@example.com', 'phone' => '+63 919 345 6789', 'joined' => 'Mar 18, 2026', 'orders' => 31, 'spent' => 61420.75, 'status' => 'Active', 'initials' => 'SM'],
            ['id' => 'CUS-1004', 'name' => 'Lucas Villanueva', 'email' => 'lucas.v@example.com', 'phone' => '+63 920 456 7890', 'joined' => 'Apr 09, 2026', 'orders' => 9, 'spent' => 12990.00, 'status' => 'Inactive', 'initials' => 'LV'],
            ['id' => 'CUS-1005', 'name' => 'Isabella Cruz', 'email' => 'isabella.cruz@example.com', 'phone' => '+63 921 567 8901', 'joined' => 'May 27, 2026', 'orders' => 15, 'spent' => 27435.25, 'status' => 'Active', 'initials' => 'IC'],
            ['id' => 'CUS-1006', 'name' => 'Noah Bautista', 'email' => 'noah.bautista@example.com', 'phone' => '+63 922 678 9012', 'joined' => 'Jun 14, 2026', 'orders' => 12, 'spent' => 19860.00, 'status' => 'Active', 'initials' => 'NB'],
        ];

        return view('customers.index', compact('customers'));
    }
}
