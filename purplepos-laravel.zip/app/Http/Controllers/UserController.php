<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class UserController extends Controller
{
    /** Display staff accounts using temporary static data. */
    public function index(): View
    {
        $users = [
            ['id' => 'USR-001', 'name' => 'Karl Ramos', 'email' => 'karl.ramos@purplepos.test', 'role' => 'Administrator', 'last_active' => 'Today, 9:42 AM', 'status' => 'Active', 'initials' => 'KR'],
            ['id' => 'USR-002', 'name' => 'Enzo Garcia', 'email' => 'enzo@purplepos.test', 'role' => 'Store Manager', 'last_active' => 'Today, 8:15 AM', 'status' => 'Active', 'initials' => 'EG'],
            ['id' => 'USR-003', 'name' => 'Althea Ramos', 'email' => 'althea@purplepos.test', 'role' => 'Cashier', 'last_active' => 'Yesterday, 6:30 PM', 'status' => 'Active', 'initials' => 'AR'],
            ['id' => 'USR-004', 'name' => 'Joaquin Lim', 'email' => 'joaquin@purplepos.test', 'role' => 'Cashier', 'last_active' => 'Oct 24, 4:18 PM', 'status' => 'Active', 'initials' => 'JL'],
            ['id' => 'USR-005', 'name' => 'Bianca Flores', 'email' => 'bianca@purplepos.test', 'role' => 'Inventory Clerk', 'last_active' => 'Oct 22, 1:05 PM', 'status' => 'Away', 'initials' => 'BF'],
            ['id' => 'USR-006', 'name' => 'Rafael Dizon', 'email' => 'rafael@purplepos.test', 'role' => 'Auditor', 'last_active' => 'Oct 18, 10:20 AM', 'status' => 'Inactive', 'initials' => 'RD'],
        ];

        return view('users.index', compact('users'));
    }
}
